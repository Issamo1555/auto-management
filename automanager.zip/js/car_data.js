/**
 * Car Data
 * List of popular brands and models for the dropdowns.
 * Logos are sourced from a public CDN (logo.clearbit.com or similar) or placeholders.
 */
const CAR_DATA = [
    {
        brand: "Peugeot",
        logo: "https://logo.clearbit.com/peugeot.com",
        models: ["208", "308", "3008", "5008", "2008", "508", "Rifter", "Partner"]
    },
    {
        brand: "Renault",
        logo: "https://logo.clearbit.com/renault.fr",
        models: ["Clio", "Megane", "Captur", "Arkana", "Austral", "Espace", "Twingo", "Zoe"]
    },
    {
        brand: "Citroën",
        logo: "https://logo.clearbit.com/citroen.com",
        models: ["C3", "C4", "C5 Aircross", "Berlingo", "C3 Aircross", "Ami"]
    },
    {
        brand: "Volkswagen",
        logo: "https://logo.clearbit.com/vw.com",
        models: ["Golf", "Polo", "Tiguan", "T-Roc", "Passat", "ID.3", "ID.4"]
    },
    {
        brand: "BMW",
        logo: "https://logo.clearbit.com/bmw.com",
        models: ["Série 1", "Série 3", "X1", "X3", "X5", "Série 5", "i4"]
    },
    {
        brand: "Mercedes-Benz",
        logo: "https://logo.clearbit.com/mercedes-benz.com",
        models: ["Classe A", "Classe C", "GLA", "GLC", "Classe E", "CLA"]
    },
    {
        brand: "Audi",
        logo: "https://logo.clearbit.com/audi.com",
        models: ["A1", "A3", "A4", "Q3", "Q5", "A6", "e-tron"]
    },
    {
        brand: "Toyota",
        logo: "https://logo.clearbit.com/toyota.com",
        models: ["Yaris", "Corolla", "RAV4", "C-HR", "Aygo", "Prius"]
    },
    {
        brand: "Ford",
        logo: "https://logo.clearbit.com/ford.com",
        models: ["Fiesta", "Focus", "Puma", "Kuga", "Mustang", "Ranger"]
    },
    {
        brand: "Fiat",
        logo: "https://logo.clearbit.com/fiat.com",
        models: ["500", "Panda", "Tipo", "500X"]
    },
    {
        brand: "Tesla",
        logo: "https://logo.clearbit.com/tesla.com",
        models: ["Model 3", "Model Y", "Model S", "Model X"]
    },
    {
        brand: "Autre",
        logo: "",
        models: []
    }
];

const MOTORCYCLE_DATA = [
    {
        brand: "Yamaha",
        logo: "https://logo.clearbit.com/yamaha-motor.com",
        models: ["MT-07", "MT-09", "YZF-R1", "YZF-R6", "Tracer 900", "TMAX", "XSR700"]
    },
    {
        brand: "Honda",
        logo: "https://logo.clearbit.com/honda.com",
        models: ["CB500F", "CB650R", "CBR1000RR", "Africa Twin", "NC750X", "Forza 750", "PCX"]
    },
    {
        brand: "Kawasaki",
        logo: "https://logo.clearbit.com/kawasaki.com",
        models: ["Ninja 650", "Z900", "Ninja ZX-10R", "Versys 650", "Z H2", "Ninja 400"]
    },
    {
        brand: "Suzuki",
        logo: "https://logo.clearbit.com/suzuki.com",
        models: ["GSX-R1000", "GSX-S750", "V-Strom 650", "Hayabusa", "SV650", "Burgman 400"]
    },
    {
        brand: "Ducati",
        logo: "https://logo.clearbit.com/ducati.com",
        models: ["Panigale V4", "Monster", "Multistrada V4", "Scrambler", "Diavel", "SuperSport"]
    },
    {
        brand: "BMW",
        logo: "https://logo.clearbit.com/bmw.com",
        models: ["R 1250 GS", "S 1000 RR", "F 900 R", "R nineT", "C 400 GT", "G 310 R"]
    },
    {
        brand: "KTM",
        logo: "https://logo.clearbit.com/ktm.com",
        models: ["Duke 390", "Duke 790", "1290 Super Duke R", "Adventure 890", "RC 390"]
    },
    {
        brand: "Harley-Davidson",
        logo: "https://logo.clearbit.com/harley-davidson.com",
        models: ["Sportster S", "Street Bob", "Fat Boy", "Road Glide", "Pan America 1250"]
    },
    {
        brand: "Triumph",
        logo: "https://logo.clearbit.com/triumph.co.uk",
        models: ["Street Triple", "Speed Triple", "Tiger 900", "Bonneville", "Rocket 3"]
    },
    {
        brand: "Autre",
        logo: "",
        models: []
    }
];

const TRUCK_DATA = [
    {
        brand: "Renault Trucks",
        logo: "https://logo.clearbit.com/renault-trucks.com",
        models: ["T", "C", "K", "D", "D Wide"]
    },
    {
        brand: "Volvo Trucks",
        logo: "https://logo.clearbit.com/volvotrucks.com",
        models: ["FH", "FM", "FMX", "FL", "FE"]
    },
    {
        brand: "Scania",
        logo: "https://logo.clearbit.com/scania.com",
        models: ["R-Series", "S-Series", "P-Series", "G-Series", "L-Series"]
    },
    {
        brand: "Mercedes-Benz",
        logo: "https://logo.clearbit.com/mercedes-benz.com",
        models: ["Actros", "Arocs", "Atego", "Econic", "Sprinter"]
    },
    {
        brand: "MAN",
        logo: "https://logo.clearbit.com/man.eu",
        models: ["TGX", "TGS", "TGM", "TGL"]
    },
    {
        brand: "DAF",
        logo: "https://logo.clearbit.com/daf.com",
        models: ["XF", "XG", "XG+", "CF", "LF"]
    },
    {
        brand: "Iveco",
        logo: "https://logo.clearbit.com/iveco.com",
        models: ["S-Way", "X-Way", "Eurocargo", "Daily"]
    },
    {
        brand: "Ford",
        logo: "https://logo.clearbit.com/ford.com",
        models: ["Transit", "Ranger", "F-150", "F-250", "F-350"]
    },
    {
        brand: "Isuzu",
        logo: "https://logo.clearbit.com/isuzu.com",
        models: ["N-Series", "F-Series", "D-Max"]
    },
    {
        brand: "Autre",
        logo: "",
        models: []
    }
];

window.CarData = CAR_DATA;
window.MotorcycleData = MOTORCYCLE_DATA;
window.TruckData = TRUCK_DATA;
